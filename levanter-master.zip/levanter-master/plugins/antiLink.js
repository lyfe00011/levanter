const { getAntiLink, bot, setAntiLink, setAllowedUrl, lang, normalizeUrl } = require('../lib/')

bot(
  {
    pattern: 'antilink ?(.*)',
    desc: lang.plugins.antilink.desc,
    type: 'group',
    onlyGroup: true,
  },
  async (message, match) => {
    const antilink = await getAntiLink(message.jid, message.id)
    const status = antilink && antilink.enabled ? 'on' : 'off'
    const action = antilink && antilink.action ? antilink.action : 'null'
    const allowedUrls = antilink && antilink.allowedUrls && antilink.allowedUrls !== 'null' ? antilink.allowedUrls : ''

    if (!match) {
      return message.send(lang.plugins.antilink.example.format(status))
    }

    const cmd = match.split(' ')[0].toLowerCase()
    const args = match.slice(cmd.length).trim()

    if (cmd === 'on' || cmd === 'off') {
      if (cmd === 'off' && status === 'off') return message.send(lang.plugins.antilink.disable)
      await setAntiLink(message.jid, cmd === 'on', message.id)
      return message.send(
        lang.plugins.antilink.status.format(cmd === 'on' ? 'enabled' : 'disabled')
      )
    }

    if (['kick', 'warn', 'null'].includes(cmd)) {
      await setAntiLink(message.jid, cmd, message.id)
      return message.send(lang.plugins.antilink.action_update.format(cmd))
    }

    if (cmd === 'allow') {
      if (!args) return message.send('*Please provide a URL to allow.*')

      const urlsToAdd = args.split(',')
        .map(u => u.trim())
        .filter(u => u)
        .map(u => normalizeUrl(u))

      const currentList = allowedUrls ? allowedUrls.split(',') : []
      const currentNormalized = currentList.map(u => normalizeUrl(u))

      const newUrls = urlsToAdd.filter(u => !currentNormalized.includes(u))

      if (newUrls.length === 0) {
        return message.send('*No new URLs to add.* All URLs already exist in the list.')
      }

      const newList = [...currentList, ...newUrls].join(',')
      await setAllowedUrl(message.jid, newList, message.id)

      return message.send(
        `*Allowed URLs updated*\n\n` +
        `Added: ${newUrls.join(', ')}\n` +
        `Total: ${[...currentList, ...newUrls].length} URL(s)\n\n` +
        `_Note: URLs are case-insensitive_`
      )
    }

    if (cmd === 'disallow') {
      if (!args) return message.send('*Please provide a URL to disallow.*')

      const urlsToDisallow = args.split(',')
        .map(u => u.trim())
        .filter(u => u)
        .map(u => `!${normalizeUrl(u)}`)

      const currentList = allowedUrls ? allowedUrls.split(',') : []

      const cleanList = currentList.filter(u => {
        const normalized = normalizeUrl(u.replace(/^!/, ''))
        return !urlsToDisallow.some(d => normalizeUrl(d.slice(1)) === normalized)
      })

      const existingDisallowed = cleanList
        .filter(u => u.startsWith('!'))
        .map(u => normalizeUrl(u.slice(1)))
      const newUrls = urlsToDisallow.filter(u => !existingDisallowed.includes(normalizeUrl(u.slice(1))))

      if (newUrls.length === 0) {
        return message.send('*No new URLs to disallow.* All URLs are already disallowed.')
      }

      const newList = [...cleanList, ...newUrls].join(',')
      await setAllowedUrl(message.jid, newList, message.id)

      return message.send(
        `*Disallowed URLs updated*\n\n` +
        `Added to blocklist: ${newUrls.map(u => u.slice(1)).join(', ')}\n` +
        `Total blocked: ${[...cleanList, ...newUrls].filter(u => u.startsWith('!')).length} URL(s)\n\n` +
        `_Note: URLs are case-insensitive_`
      )
    }

    if (cmd === 'list' || cmd === 'info') {
      if (!allowedUrls) return message.send(lang.plugins.antilink.antilink_notset)
      const list = allowedUrls.split(',')
      const allowed = list.filter(u => !u.startsWith('!')).join(', ')
      const disallowed = list.filter(u => u.startsWith('!')).map(u => u.slice(1)).join(', ')
      return message.send(
        `*Antilink Status:* ${status}\n*Action:* ${action}\n\n*Allowed:* ${allowed || 'None'}\n*Disallowed:* ${disallowed || 'None'}`
      )
    }

    if (cmd === 'clear') {
      if (!args) {
        await setAllowedUrl(message.jid, 'null', message.id)
        return message.send('*Antilink settings cleared.*')
      }

      const type = args.toLowerCase()
      const currentList = allowedUrls ? allowedUrls.split(',') : []

      if (type === 'allow' || type === 'allowed') {
        const disallowedOnly = currentList.filter(u => u.startsWith('!'))
        const newList = disallowedOnly.length > 0 ? disallowedOnly.join(',') : 'null'
        await setAllowedUrl(message.jid, newList, message.id)
        return message.send('*Allowed URLs cleared.*')
      }

      if (type === 'disallow' || type === 'disallowed') {
        const allowedOnly = currentList.filter(u => !u.startsWith('!'))
        const newList = allowedOnly.length > 0 ? allowedOnly.join(',') : 'null'
        await setAllowedUrl(message.jid, newList, message.id)
        return message.send('*Disallowed URLs cleared.*')
      }

      return message.send(lang.plugins.antilink.example.format(status))
    }

    return message.send(lang.plugins.antilink.example.format(status))
  }
)
